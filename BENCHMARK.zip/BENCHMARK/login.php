<?php
session_start();
include_once 'dbconnect.php';

if(isset($_SESSION['user'])!="")
{
    header("Location: index.html");
}

if(isset($_POST['b1']))
 {
    
    $username=$_POST['username'];
    $pwd=$_POST['password'];
    $res=mysqli_query($con,"SELECT * FROM user_info WHERE username='$username'");
    $row=mysqli_fetch_array($res);
    if($row['password']==$pwd)
    {
        $_SESSION['user']=$row['username'];
        header("Location: index.html");
    }
    else
    {
    
    echo "<script>alert('wrong username or wrong password ');</script>";

    
           
        
    }
}


mysqli_close($conn);
?>