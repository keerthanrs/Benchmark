<?php
$username="id17694258_aks";
$password="A1234567890@os";
$servername="localhost";
$dbname="id17694258_vql";
$con=mysqli_connect($servername,$username,$password,$dbname);

?>