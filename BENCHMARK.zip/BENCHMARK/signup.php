<?php



include_once 'dbconnect.php';

 if(isset($_POST['s1']))
 {
  $regno =$_POST['R1'];
 $username = $_POST['U1'];
 $firstname =$_POST['F1'];
  $lastname =$_POST['L1'];
  
 $email = $_POST['E1'];
 $pwd1 = $_POST['P1'];

 
//(username,email,password,firstname,lastname,cellphone,middlename,gender,birthday) 
  
    
   $q="INSERT INTO `user_info` (`regnumber`, `firstname`, `lastname`, `email`, `username`, `password`) VALUES ('$regno', '$firstname', '$lastname','$email','$username','$pwd1')";
  
    $res=mysqli_query($con,$q);
   
   
 if($res)
 {
        $_SESSION['user']=$username;
        header("Location: index.html");
         }
 else
 {
 ?>
        <script>alert('error while registering you...')</script>
        <?php
 }

 }
 
mysqli_close($con);

 ?>