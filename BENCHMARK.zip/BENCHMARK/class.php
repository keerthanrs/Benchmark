<?php 

include_once(dbconnect.php);
if(!$_SESSION['user'])
{

    if($_isset['s1'])
    {
        $id=$_POST['id'];
        $cname=$_POST['cname'];
        $username=$_POST['username'];
        $q="INSERT INTO `class_info` (`id`, `class_name`, `user`) VALUES ('$id', ' $cname', '$username')";
        if(mysqli_query($con,$q))
        {
            echo "Group is added!!";
             echo '<script>window.location.replace("https://benchmark47.000webhostapp.com/class.html");</script>';
        }
        else
        {
            
            echo "<script>alert(\' Login please!!!!\');";
             echo '<script>window.location.replace("https://benchmark47.000webhostapp.com/class.html");</script>';
        }
    }
    else if($_isset['s'])
    {
          $id=$_POST['id'];
        $pass=$_POST['password'];
        $username=$_POST['username'];
        $q="INSERT INTO `group_info` (`id`, `password`) VALUES (' $id', '$pass')";
        if(mysqli_query($con,$q))
        {
            echo "Group is added!!";
             echo '<script>window.location.replace("https://benchmark47.000webhostapp.com/class.html");</script>';
        }
        else
        {
            
            
        }
        
    }
    else
    {
       
             echo '<script>window.location.replace("https://benchmark47.000webhostapp.com/search.php");</script>'; 
    }
    























echo '<!DOCTYPE html>
<html class="no-js" >
    <head>
        <!-- meta charset -->
        <meta charset="utf-8">
        <!-- site title -->
        <title>GRPUPS</title>
        <!-- meta description -->
        <meta name="description" content="">
        <!-- mobile viwport meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- fevicon -->
        <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
        
        <!-- ================================
        CSS Files
        ================================= -->
        <link href="https://fonts.googleapis.com/css?family=Libre+Baskerville:400,400i|Open+Sans:400,600,700,800" rel="stylesheet">
        <link rel="stylesheet" href="css/themefisher-fonts.min.css">
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/dark.css">
        <link id="color-changer" rel="stylesheet" href="css/colors/color-0.css">
        <style>
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropbtn:hover, .dropbtn:focus {
  background-color: #3e8e41;
}

.dropdown {
  position: relative;
  display: inline-block;
}
#myBtn1 {
  position: relative;
 top:-60px;
  left:800px;
  display: inline-block;
}

.dropdown-content {
  left:220px;
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 500px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.show {display:block;}

input[type=text],input[type=submit]{
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text],input[type=submit]:focus {
  border: 3px solid #555;
}

</style>
    </head>

    <body class="dark">

       

        <div class="preview-wrapper">
            <div class="switcher-head">
                <span>Learning Objectives</span>
                <div class="switcher-trigger tf-tools"></div>
            </div>

            <div class="switcher-body">
                <h4>Choose Color:</h4>
                <ul class="color-options list-none">
                    <li class="c0" data-color="red" title="W3 school"></li>
                    <li class="c1" data-color="blue" title="GFG"></li>
                    <li class="c2" data-color="green" title="NESO"></li>
                    <li class="c3" data-color="yellow" title="IEEE UVCE"></li>
                </ul>
            </div>
        </div>

        <section class="site-wrapper">
            <div class="pt-table">
                <div class="pt-tablecell page-services relative">
                    <a href="./" class="page-close"><i class="tf-ion-close"></i></a>
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-lg-offset-1 col-lg-10">
                                <div class="page-title text-center">
                                  TECHNICAL STUDENTS
                                </div>
                                <script>
                                    function showCustomer(str) {
                                        if (str == "") {
                                                  document.getElementById("txtHint").innerHTML = "";
                                                      return;
                                                 }
                                         const xhttp = new XMLHttpRequest();
                                          xhttp.onload = function() {
                                        document.getElementById("txtHint").innerHTML = this.responseText;
                                     }
                        xhttp.open("POST", "class.php?q="+str);
                         xhttp.send();
}
                                </script>
                            <div class="hexagon-menu services clear">
                                    <div class="service-hex">
                                      <!--  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 372 424.5" style="enable-background:new 0 0 372 424.5;" xml:space="preserve">-->
                                            <div class="dropdown">
                                                <button id="myBtn" class="dropbtn">Creat Group</button>
                                                     <div id="myDropdown" class="dropdown-content">
   
                                                             <form method="POST" action="class.php">
                                                                  <label for="">GROUP ID</label>
                                                                    <input type="text" name="id" placeholder="CLASS ID">
                                                                        <label for="">GROUP NAME</label>
                                                                            <input type="text"  name="cname" placeholder="CLASS NAME">
                                                                             <label for="">USER NAME</label>
                                                                                 <input type="text"  name="username" placeholder="USERNAME">
                                                                                 <label for=""></label>
                                                                                <input type="submit"  name="s1" placeholder="SUBMIT">
                                                                                   </form>
                                                                                     </div>
                                                 </div>
                                               
                                                <div class="dropdown"  >
                                                <button id="myBtn1" class="dropbtn">Join Group</button>
                                                     <div id="myDropdown1" class="dropdown-content">
   
                                                             <form method="POST" action="class.php">
                                                                  <label for="">GROUP ID</label>
                                                                    <input type="text" name="id" placeholder="CLASS ID">
                                                                         <label for="">USER NAME</label>
                                                                                 <input type="text"  name="username" placeholder="USERNAME">
                                                                                 <label for=""></label>
                                                                             <label for="">PASSWORD</label>
                                                                                 <input type="text"  name="password" placeholder="PASSWORD">
                                                                                 <label for=""></label>
                                                                                <input type="submit"  name="s1" placeholder="SUBMIT">
                                                                                   </form>
                                                                                     </div>
                                                 </div>
                                                                                       
                                                                            
                                        <script>
// Get the button, and when the user clicks on it, execute myFunction

document.getElementById("myBtn").onclick = function() {myFunction()};

/* myFunction toggles between adding and removing the show class, which is used to hide and show the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}
</script>
  <script>
// Get the button, and when the user clicks on it, execute myFunction

document.getElementById("myBtn1").onclick = function() {Function()};

/* myFunction toggles between adding and removing the show class, which is used to hide and show the dropdown content */
function Function() {
  document.getElementById("myDropdown1").classList.toggle("show");
}
</script>
                                            
                                        </svg>

                                        
                                   
                                   
                                    
                            </div> <!-- /.col-xs-12 -->

                        </div> <!-- /.row -->
                    </div> <!-- /.container -->

                    <nav class="page-nav clear">
                        <div class="container">
                            
                        </div>
                        <!-- /.page-nav -->
                    </nav>
                    <!-- /.container -->

                </div> <!-- /.pt-tablecell -->
            </div> <!-- /.pt-table -->
        </section> <!-- /.site-wrapper -->
        
        <!-- ================================
        JavaScript Libraries
        ================================= -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/jquery.easing.min.js"></script>
        <script src="js/isotope.pkgd.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery-validation.min.js"></script>
        <script src="js/form.min.js"></script>
        <script src="js/main.js"></script>
    </body>
</html> ';
}
else
{
    echo '<script>alert(\' Login please!!!!\');
    window.location.replace("https://benchmark47.000webhostapp.com/login.html");</script>';
}
?>